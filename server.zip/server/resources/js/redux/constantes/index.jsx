// src/js/constants/action-types.js

export const ADD_SOLUTION = 'ADD_SOLUTION';
export const DELETE_SOLUTION = 'DELETE_SOLUTION';

export const FETCH_SOLUTION = 'FETCH_SOLUTION';
export const UPDATE_SOLUTION = 'UPDATE_SOLUTION';
