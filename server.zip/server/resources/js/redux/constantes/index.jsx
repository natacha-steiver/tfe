// src/js/constants/action-types.js

//solutions
export const ADD_SOLUTION = 'ADD_SOLUTION';
export const DELETE_SOLUTION = 'DELETE_SOLUTION';
export const FETCH_SOLUTION = 'FETCH_SOLUTION';
export const UPDATE_SOLUTION = 'UPDATE_SOLUTION';

//authentification

export const  POST_LOGIN='POST_LOGIN';
export const  GET_LOGIN='GET_LOGIN';
export const  POST_REGISTER='POST_REGISTER';
export const  GET_REGISTER='GET_REGISTER';
